<?Php

	include "db.php"; // call the database connection

	$scf=$_FILES["scf"]["name"]; //User Photo
	if($scf!=""){
		$scf=$_FILES["scf"]["name"];
		$fileSize = $_FILES["scf"]["size"]/1024;
		$fileType = $_FILES["scf"]["type"];
	}
	else{
		$newscf="";
		$fileSize ="";
		$fileType ="";
	}

	$scname=trim(htmlspecialchars($_POST["scname"]));
	$sccountry=trim(htmlspecialchars($_POST["sccountry"]));
	$cldate=trim(htmlspecialchars($_POST["cldate"]));
	$comnt=trim(htmlspecialchars($_POST["comnt"]));

//	$sql="SELECT * FROM cp_funds where fnd_name='$desig'";
//	$rs=mysqli_query($con,$sql);


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="css/controls.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form name="frm" method="post" enctype="multipart/form-data" action="addfooddata.php">
<table width="100%" border="0">
  <tr>
    <td colspan="3" align="center" style="font-size:18px;font-weight:700">

        <?Php
			
					if($scf!=""){//if the photo is added
						if (($fileSize<512000)){
							$n=rand();
							$target="foriegnschols/"; //Remote folder. Photos are uploaded to this folder
							$path=$target.basename($scf); // set the photo path
							//$rno=rand();//Genarate the random number to change the photo name
							move_uploaded_file($_FILES['scf']['tmp_name'],$path); // Upload the photo
							$newscf=$n."_".$scf;//Change the name of the photo with the random number. This will avoid the Overwritings.
						
							//Rename the uploaded photo with the new name (with the random number)
							rename("foriegnschols/$scf","foriegnschols/$newscf");
							
						}
						else{ //invalied Photo
                        	echo "ප්‍රමිතියෙන් තොර ලිපිගොනුවකි! කරුණාකර <a href='foreignschols.php'>මෙතනින්</a>නැවත උත්සහ කරන්න...<br>";
							die("Invalied File format");
						}
					}
			
				$sqlinsert = "insert into cp_foreignschols (fs_file,fs_name,fs_country,fs_closingdate,fs_comment) 
							values ('".$newscf."','".$scname."','".$sccountry."','".$cldate."','".$comnt."')";
 						$rsinsert = mysqli_query($con,$sqlinsert);
						if(!$rsinsert){
							echo "Error : ".mysqli_error($con);	
						}
						else{
							echo "විදේශ ශිෂ්‍යත්ව ඇතුලත් කිරීම සාර්ථකයි...නව විදේශ ශිෂ්‍යත්වයක් ඇතුලත් කිරීම සඳහා <a href='foreignschols.php'>මෙතනින්</a> යන්න<br><br>
							";
						}
						
  
		?>    
    
    </td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td align="left">&nbsp;</td>
  </tr>
  </table>
</form>
</body>
</html>